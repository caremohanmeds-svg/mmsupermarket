// server.js – MM Supermarket Main Server
require('dotenv').config();
const express    = require('express');
const cors       = require('cors');
const helmet     = require('helmet');
const compression = require('compression');
const rateLimit  = require('express-rate-limit');
const path       = require('path');

const app = express();

// ── Security & Performance ───────────────────────────────────
app.use(helmet({ contentSecurityPolicy: false }));
app.use(compression());
app.use(cors({
  origin:      process.env.FRONTEND_URL || '*',
  credentials: true
}));

// Rate limiting
const limiter = rateLimit({
  windowMs: parseInt(process.env.RATE_LIMIT_WINDOW_MS) || 15 * 60 * 1000,
  max:      parseInt(process.env.RATE_LIMIT_MAX)        || 200,
  message:  { success:false, message:'Too many requests, please try again later.' }
});
app.use('/api/', limiter);

// ── Body Parsing ─────────────────────────────────────────────
app.use(express.json({ limit:'10mb' }));
app.use(express.urlencoded({ extended:true, limit:'10mb' }));

// ── Static files (uploaded images) ───────────────────────────
app.use('/uploads', express.static(path.join(__dirname, 'uploads')));

// ── Serve frontend build (production) ────────────────────────
app.use(express.static(path.join(__dirname, '../frontend/dist')));

// ── API Routes ───────────────────────────────────────────────
app.use('/api/auth',     require('./routes/auth'));
app.use('/api/products', require('./routes/products'));
app.use('/api/orders',   require('./routes/orders'));
app.use('/api/admin',    require('./routes/admin'));

// Promo code validation endpoint
app.post('/api/promo/validate', async (req, res) => {
  const { code, subtotal } = req.body;
  const db = require('./config/db');
  try {
    const [rows] = await db.query(
      `SELECT * FROM promo_codes WHERE code=? AND is_active=1
       AND (valid_until IS NULL OR valid_until > NOW())
       AND used_count < max_uses`, [code?.toUpperCase()]);
    if (!rows.length) return res.json({ success:false, message:'Invalid or expired promo code' });
    const promo = rows[0];
    if (subtotal < promo.min_order)
      return res.json({ success:false, message:`Minimum order ₹${promo.min_order} required for this code` });
    const discount = promo.type === 'percent'
      ? Math.round(subtotal * promo.value / 100)
      : promo.value;
    res.json({ success:true, discount, message:`${promo.value}${promo.type==='percent'?'%':'₹'} discount applied!` });
  } catch (err) { res.status(500).json({ success:false, message:err.message }); }
});

// ── Health check ─────────────────────────────────────────────
app.get('/api/health', (req, res) => res.json({ status:'ok', service:'MM Supermarket API', time:new Date() }));

// ── Catch-all: serve frontend SPA ────────────────────────────
app.get('*', (req, res) => {
  res.sendFile(path.join(__dirname, '../frontend/dist/index.html'));
});

// ── Error handler ─────────────────────────────────────────────
app.use((err, req, res, next) => {
  console.error(err.stack);
  res.status(500).json({ success:false, message:'Internal server error' });
});

// ── Start ─────────────────────────────────────────────────────
const PORT = process.env.PORT || 5000;
app.listen(PORT, () => {
  console.log(`\n🛒  MM Supermarket API running on port ${PORT}`);
  console.log(`🌐  Frontend: ${process.env.FRONTEND_URL}`);
  console.log(`📦  Env: ${process.env.NODE_ENV}\n`);
});
