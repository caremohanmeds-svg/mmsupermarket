const jwt = require('jsonwebtoken');
const db  = require('../config/db');

exports.protect = async (req, res, next) => {
  try {
    const token = req.headers.authorization?.startsWith('Bearer ')
      ? req.headers.authorization.split(' ')[1] : req.cookies?.token;
    if (!token) return res.status(401).json({ success:false, message:'Not authorised. Please login.' });
    const decoded = jwt.verify(token, process.env.JWT_SECRET);
    const [rows]  = await db.query('SELECT id,name,email,phone,role FROM users WHERE id=? AND is_active=1',[decoded.id]);
    if (!rows.length) return res.status(401).json({ success:false, message:'User not found.' });
    req.user = rows[0]; next();
  } catch { return res.status(401).json({ success:false, message:'Invalid token.' }); }
};

exports.adminOnly = (req, res, next) => {
  if (req.user?.role !== 'admin')
    return res.status(403).json({ success:false, message:'Admin access required.' });
  next();
};
