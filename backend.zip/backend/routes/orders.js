// routes/orders.js  – Create order, Razorpay UPI payment, track, admin manage
const express  = require('express');
const Razorpay = require('razorpay');
const crypto   = require('crypto');
const db       = require('../config/db');
const { protect, adminOnly } = require('../middleware/auth');
const router   = express.Router();

const razorpay = new Razorpay({
  key_id:     process.env.RAZORPAY_KEY_ID,
  key_secret: process.env.RAZORPAY_KEY_SECRET
});

// Generate readable order ID
function makeOrderId() {
  return 'ORD-' + Date.now().toString(36).toUpperCase() + Math.random().toString(36).slice(2,5).toUpperCase();
}

// ─────────────────────────────────────────────
// POST /api/orders/create-razorpay-order
// Step 1: Create Razorpay order (returns order_id for frontend)
// ─────────────────────────────────────────────
router.post('/create-razorpay-order', async (req, res) => {
  try {
    const { amount } = req.body; // amount in ₹
    if (!amount || amount < 1)
      return res.status(400).json({ success:false, message:'Invalid amount.' });

    const rzpOrder = await razorpay.orders.create({
      amount:   Math.round(amount * 100),  // paise
      currency: 'INR',
      receipt:  'rcpt_' + Date.now(),
      payment_capture: 1
    });

    res.json({
      success:  true,
      rzp_order_id: rzpOrder.id,
      amount:   rzpOrder.amount,
      currency: rzpOrder.currency,
      key_id:   process.env.RAZORPAY_KEY_ID
    });
  } catch (err) { res.status(500).json({ success:false, message: err.message }); }
});

// ─────────────────────────────────────────────
// POST /api/orders  – Step 2: Verify payment + save order
// ─────────────────────────────────────────────
router.post('/', async (req, res) => {
  const {
    name, phone, email,
    address_line1, address_line2, city, state, pincode,
    items, subtotal, delivery_fee, discount, total,
    payment_method, promo_code,
    razorpay_order_id, razorpay_payment_id, razorpay_signature
  } = req.body;

  // Validate required fields
  if (!name || !phone || !address_line1 || !pincode || !items?.length)
    return res.status(400).json({ success:false, message:'Missing required fields.' });

  // Verify Razorpay signature (for UPI/online payments)
  let payment_status = 'pending';
  if (payment_method !== 'cod' && razorpay_payment_id) {
    const body_str = razorpay_order_id + '|' + razorpay_payment_id;
    const expected = crypto.createHmac('sha256', process.env.RAZORPAY_KEY_SECRET)
                           .update(body_str).digest('hex');
    if (expected !== razorpay_signature)
      return res.status(400).json({ success:false, message:'Payment verification failed.' });
    payment_status = 'paid';
  }

  const conn = await db.getConnection();
  try {
    await conn.beginTransaction();
    const order_id = makeOrderId();

    // Verify stock & collect product data
    const productIds = items.map(i => i.product_id);
    const [prods] = await conn.query(
      'SELECT id,name,emoji,weight_unit,price,stock FROM products WHERE id IN (?)', [productIds]
    );
    const prodMap = Object.fromEntries(prods.map(p => [p.id, p]));

    for (const item of items) {
      const prod = prodMap[item.product_id];
      if (!prod) throw new Error(`Product ${item.product_id} not found`);
      if (prod.stock < item.quantity) throw new Error(`"${prod.name}" is out of stock.`);
    }

    // Insert order
    const [orderRes] = await conn.query(
      `INSERT INTO orders
         (order_id,user_id,name,phone,email,address_line1,address_line2,city,state,pincode,
          subtotal,delivery_fee,discount,total,payment_method,payment_status,
          razorpay_order_id,razorpay_payment_id,promo_code,status)
       VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)`,
      [order_id, req.user?.id||null, name, phone, email||null,
       address_line1, address_line2||null, city||'Prayagraj', state||'Uttar Pradesh', pincode,
       subtotal, delivery_fee||0, discount||0, total,
       payment_method, payment_status,
       razorpay_order_id||null, razorpay_payment_id||null, promo_code||null,
       payment_method==='cod' ? 'confirmed' : 'confirmed']
    );
    const dbOrderId = orderRes.insertId;

    // Insert order items & deduct stock
    for (const item of items) {
      const prod = prodMap[item.product_id];
      await conn.query(
        'INSERT INTO order_items (order_id,product_id,name,emoji,weight_unit,price,quantity,total) VALUES (?,?,?,?,?,?,?,?)',
        [dbOrderId, item.product_id, prod.name, prod.emoji, prod.weight_unit,
         parseFloat(item.price), item.quantity, parseFloat(item.price)*item.quantity]
      );
      await conn.query('UPDATE products SET stock=stock-?, sold_count=sold_count+? WHERE id=?',
        [item.quantity, item.quantity, item.product_id]);
    }

    // Update promo code usage
    if (promo_code) await conn.query('UPDATE promo_codes SET used_count=used_count+1 WHERE code=?', [promo_code]);

    await conn.commit();
    res.status(201).json({ success:true, message:'Order placed!', order_id, total });
  } catch (err) {
    await conn.rollback();
    res.status(500).json({ success:false, message: err.message });
  } finally {
    conn.release();
  }
});

// ─────────────────────────────────────────────
// GET /api/orders/track/:order_id  – public order tracking
// ─────────────────────────────────────────────
router.get('/track/:order_id', async (req, res) => {
  try {
    const [rows] = await db.query(
      `SELECT o.order_id, o.name, o.status, o.payment_method, o.payment_status,
              o.total, o.created_at, o.city,
              oi.name AS item_name, oi.emoji, oi.quantity, oi.price, oi.total AS item_total
       FROM orders o
       LEFT JOIN order_items oi ON oi.order_id=o.id
       WHERE o.order_id=?`, [req.params.order_id]
    );
    if (!rows.length) return res.status(404).json({ success:false, message:'Order not found.' });

    const order = {
      order_id:       rows[0].order_id,
      name:           rows[0].name,
      status:         rows[0].status,
      payment_method: rows[0].payment_method,
      payment_status: rows[0].payment_status,
      total:          rows[0].total,
      created_at:     rows[0].created_at,
      city:           rows[0].city,
      items:          rows.filter(r=>r.item_name).map(r=>({ name:r.item_name, emoji:r.emoji, qty:r.quantity, price:r.price, total:r.item_total }))
    };

    const statusSteps = ['pending','confirmed','processing','packed','out_for_delivery','delivered'];
    const currentIdx  = statusSteps.indexOf(order.status);
    order.steps = statusSteps.map((s, i) => ({
      key:   s,
      label: s.replace(/_/g,' ').replace(/\b\w/g,c=>c.toUpperCase()),
      done:  i <= currentIdx,
      active: i === currentIdx
    }));

    res.json({ success:true, order });
  } catch (err) { res.status(500).json({ success:false, message: err.message }); }
});

// ─────────────────────────────────────────────
// GET /api/orders/my  – logged-in user's orders
// ─────────────────────────────────────────────
router.get('/my', protect, async (req, res) => {
  try {
    const [orders] = await db.query(
      `SELECT o.*, GROUP_CONCAT(oi.emoji SEPARATOR '') AS emojis
       FROM orders o LEFT JOIN order_items oi ON oi.order_id=o.id
       WHERE o.user_id=? GROUP BY o.id ORDER BY o.created_at DESC`, [req.user.id]
    );
    res.json({ success:true, orders });
  } catch (err) { res.status(500).json({ success:false, message: err.message }); }
});

// ─────────────────────────────────────────────
// GET /api/orders  – ADMIN: all orders
// ─────────────────────────────────────────────
router.get('/', protect, adminOnly, async (req, res) => {
  try {
    const { status, page=1, limit=20 } = req.query;
    const offset = (page-1)*limit;
    let where = '1=1'; const params = [];
    if (status) { where += ' AND o.status=?'; params.push(status); }
    const [orders] = await db.query(
      `SELECT o.*, COUNT(oi.id) AS item_count
       FROM orders o LEFT JOIN order_items oi ON oi.order_id=o.id
       WHERE ${where} GROUP BY o.id ORDER BY o.created_at DESC LIMIT ? OFFSET ?`,
      [...params, parseInt(limit), parseInt(offset)]
    );
    res.json({ success:true, orders });
  } catch (err) { res.status(500).json({ success:false, message: err.message }); }
});

// PATCH /api/orders/:id/status  – ADMIN: update order status
router.patch('/:id/status', protect, adminOnly, async (req, res) => {
  const { status } = req.body;
  const valid = ['pending','confirmed','processing','packed','out_for_delivery','delivered','cancelled','returned'];
  if (!valid.includes(status)) return res.status(400).json({ success:false, message:'Invalid status.' });
  try {
    await db.query('UPDATE orders SET status=? WHERE id=?', [status, req.params.id]);
    res.json({ success:true, message:'Order status updated.' });
  } catch (err) { res.status(500).json({ success:false, message: err.message }); }
});

// POST /api/orders/webhook  – Razorpay webhook (for async payment confirmation)
router.post('/webhook', express.raw({type:'application/json'}), (req, res) => {
  const sig  = req.headers['x-razorpay-signature'];
  const body = req.body.toString();
  const expected = crypto.createHmac('sha256', process.env.RAZORPAY_WEBHOOK_SECRET)
                         .update(body).digest('hex');
  if (sig !== expected) return res.status(400).send('Invalid signature');
  const event = JSON.parse(body);
  if (event.event === 'payment.captured') {
    const pid = event.payload.payment.entity.id;
    db.query("UPDATE orders SET payment_status='paid',status='confirmed' WHERE razorpay_payment_id=?", [pid])
      .catch(console.error);
  }
  res.json({ received: true });
});

// GET /api/orders/validate-promo/:code
router.get('/validate-promo/:code', async (req, res) => {
  try {
    const [rows] = await db.query(
      `SELECT * FROM promo_codes WHERE code=? AND is_active=1
       AND (valid_until IS NULL OR valid_until > NOW())
       AND used_count < max_uses`, [req.params.code]
    );
    if (!rows.length) return res.status(404).json({ success:false, message:'Invalid or expired promo code.' });
    res.json({ success:true, promo: rows[0] });
  } catch (err) { res.status(500).json({ success:false, message: err.message }); }
});

module.exports = router;
