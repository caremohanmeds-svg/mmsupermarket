// routes/admin.js  – dashboard stats & management
const router = require('express').Router();
const db     = require('../config/db');
const { protect, adminOnly } = require('../middleware/auth');

router.use(protect, adminOnly);

// GET /api/admin/dashboard
router.get('/dashboard', async (req, res) => {
  try {
    const today = new Date().toISOString().slice(0,10);
    const [[todayOrders]]  = await db.query("SELECT COUNT(*) AS n, IFNULL(SUM(total),0) AS rev FROM orders WHERE DATE(created_at)=?", [today]);
    const [[totalOrders]]  = await db.query("SELECT COUNT(*) AS n FROM orders");
    const [[totalRevenue]] = await db.query("SELECT IFNULL(SUM(total),0) AS rev FROM orders WHERE payment_status='paid'");
    const [[customers]]    = await db.query("SELECT COUNT(*) AS n FROM users WHERE role='customer'");
    const [[lowStock]]     = await db.query("SELECT COUNT(*) AS n FROM products WHERE stock <= min_stock AND is_active=1");
    const [recentOrders]   = await db.query("SELECT * FROM orders ORDER BY created_at DESC LIMIT 10");
    const [topProducts]    = await db.query(
      "SELECT p.name, p.emoji, p.sold_count, p.price FROM products p ORDER BY p.sold_count DESC LIMIT 5");
    const [catSales]       = await db.query(
      `SELECT c.name, SUM(oi.quantity) AS units_sold
       FROM order_items oi JOIN products p ON p.id=oi.product_id
       JOIN categories c ON c.id=p.category_id GROUP BY c.id ORDER BY units_sold DESC`);

    res.json({ success:true, data:{
      today_orders: todayOrders.n,
      today_revenue: todayOrders.rev,
      total_orders: totalOrders.n,
      total_revenue: totalRevenue.rev,
      total_customers: customers.n,
      low_stock_count: lowStock.n,
      recent_orders: recentOrders,
      top_products: topProducts,
      category_sales: catSales
    }});
  } catch (err) { res.status(500).json({ success:false, message:err.message }); }
});

// GET /api/admin/customers
router.get('/customers', async (req, res) => {
  try {
    const [rows] = await db.query(
      `SELECT u.id, u.name, u.phone, u.email, u.created_at,
       COUNT(o.id) AS total_orders, IFNULL(SUM(o.total),0) AS total_spent
       FROM users u LEFT JOIN orders o ON o.user_id=u.id
       WHERE u.role='customer' GROUP BY u.id ORDER BY u.created_at DESC`);
    res.json({ success:true, data:rows });
  } catch (err) { res.status(500).json({ success:false, message:err.message }); }
});

// GET /api/admin/inventory
router.get('/inventory', async (req, res) => {
  try {
    const [rows] = await db.query(
      `SELECT p.id, p.name, p.emoji, p.stock, p.min_stock, c.name AS category
       FROM products p JOIN categories c ON c.id=p.category_id
       WHERE p.is_active=1 ORDER BY (p.stock - p.min_stock) ASC`);
    res.json({ success:true, data:rows });
  } catch (err) { res.status(500).json({ success:false, message:err.message }); }
});

// PATCH /api/admin/inventory/:id
router.patch('/inventory/:id', async (req, res) => {
  try {
    await db.query('UPDATE products SET stock=? WHERE id=?', [req.body.stock, req.params.id]);
    res.json({ success:true, message:'Stock updated' });
  } catch (err) { res.status(500).json({ success:false, message:err.message }); }
});

// GET /api/admin/reports/monthly
router.get('/reports/monthly', async (req, res) => {
  try {
    const [monthly] = await db.query(
      `SELECT DATE_FORMAT(created_at,'%Y-%m') AS month,
       COUNT(*) AS orders, SUM(total) AS revenue
       FROM orders GROUP BY month ORDER BY month DESC LIMIT 12`);
    res.json({ success:true, data:monthly });
  } catch (err) { res.status(500).json({ success:false, message:err.message }); }
});

// GET /api/admin/promo-codes
router.get('/promo-codes', async (req, res) => {
  try {
    const [rows] = await db.query('SELECT * FROM promo_codes ORDER BY created_at DESC');
    res.json({ success:true, data:rows });
  } catch (err) { res.status(500).json({ success:false, message:err.message }); }
});

// POST /api/admin/promo-codes
router.post('/promo-codes', async (req, res) => {
  const { code, type, value, min_order, max_uses, valid_until } = req.body;
  try {
    await db.query('INSERT INTO promo_codes (code,type,value,min_order,max_uses,valid_until) VALUES (?,?,?,?,?,?)',
      [code.toUpperCase(), type, value, min_order||0, max_uses||1000, valid_until||null]);
    res.status(201).json({ success:true, message:'Promo code created' });
  } catch (err) { res.status(500).json({ success:false, message:err.message }); }
});

module.exports = router;
