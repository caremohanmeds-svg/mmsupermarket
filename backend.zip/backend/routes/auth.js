// routes/auth.js  – Register, Login (OTP + Password), Refresh Token
const express   = require('express');
const bcrypt    = require('bcryptjs');
const jwt       = require('jsonwebtoken');
const { body, validationResult } = require('express-validator');
const db        = require('../config/db');
const { protect } = require('../middleware/auth');
const router    = express.Router();

const signToken = (id) =>
  jwt.sign({ id }, process.env.JWT_SECRET, { expiresIn: process.env.JWT_EXPIRES_IN || '7d' });

// POST /api/auth/register
router.post('/register',
  [body('phone').isMobilePhone('en-IN').withMessage('Valid Indian phone required'),
   body('name').trim().notEmpty().withMessage('Name required'),
   body('password').isLength({ min:6 }).withMessage('Password min 6 chars')],
  async (req, res) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) return res.status(400).json({ success:false, errors: errors.array() });

    const { name, phone, email, password } = req.body;
    try {
      const [ex] = await db.query('SELECT id FROM users WHERE phone=?', [phone]);
      if (ex.length) return res.status(409).json({ success:false, message:'Phone already registered.' });

      const hash = await bcrypt.hash(password, 10);
      const [result] = await db.query(
        'INSERT INTO users (name,phone,email,password) VALUES (?,?,?,?)',
        [name, phone, email||null, hash]
      );
      const token = signToken(result.insertId);
      res.status(201).json({ success:true, message:'Account created!', token, user:{ id:result.insertId, name, phone, email, role:'customer' } });
    } catch (err) {
      res.status(500).json({ success:false, message: err.message });
    }
  }
);

// POST /api/auth/login  (password)
router.post('/login',
  [body('phone').notEmpty(), body('password').notEmpty()],
  async (req, res) => {
    const { phone, password } = req.body;
    try {
      const [rows] = await db.query('SELECT * FROM users WHERE phone=? AND is_active=1', [phone]);
      if (!rows.length) return res.status(401).json({ success:false, message:'Invalid credentials.' });
      const user = rows[0];
      const match = await bcrypt.compare(password, user.password);
      if (!match) return res.status(401).json({ success:false, message:'Invalid credentials.' });
      const token = signToken(user.id);
      res.json({ success:true, token, user:{ id:user.id, name:user.name, phone:user.phone, email:user.email, role:user.role } });
    } catch (err) {
      res.status(500).json({ success:false, message: err.message });
    }
  }
);

// POST /api/auth/send-otp
router.post('/send-otp', async (req, res) => {
  const { phone } = req.body;
  if (!phone) return res.status(400).json({ success:false, message:'Phone required.' });
  const otp = Math.floor(100000 + Math.random()*900000).toString();
  const expires = new Date(Date.now() + 10*60*1000); // 10 min
  try {
    await db.query(
      'INSERT INTO users (phone,otp,otp_expires) VALUES (?,?,?) ON DUPLICATE KEY UPDATE otp=?,otp_expires=?',
      [phone, otp, expires, otp, expires]
    );
    // TODO: integrate Twilio SMS here
    console.log(`OTP for ${phone}: ${otp}`); // remove in prod
    res.json({ success:true, message:'OTP sent!', ...(process.env.NODE_ENV==='development' && { otp }) });
  } catch (err) {
    res.status(500).json({ success:false, message: err.message });
  }
});

// POST /api/auth/verify-otp
router.post('/verify-otp', async (req, res) => {
  const { phone, otp } = req.body;
  try {
    const [rows] = await db.query(
      'SELECT * FROM users WHERE phone=? AND otp=? AND otp_expires > NOW()', [phone, otp]
    );
    if (!rows.length) return res.status(400).json({ success:false, message:'Invalid or expired OTP.' });
    await db.query('UPDATE users SET otp=NULL,otp_expires=NULL WHERE phone=?', [phone]);
    const user = rows[0];
    const token = signToken(user.id);
    res.json({ success:true, token, user:{ id:user.id, name:user.name, phone:user.phone, email:user.email, role:user.role } });
  } catch (err) {
    res.status(500).json({ success:false, message: err.message });
  }
});

// GET /api/auth/me
router.get('/me', protect, (req, res) => res.json({ success:true, user: req.user }));

module.exports = router;
