// routes/products.js
const express  = require('express');
const db       = require('../config/db');
const { protect, adminOnly } = require('../middleware/auth');
const upload   = require('../middleware/upload');
const router   = express.Router();

// GET /api/products  – public listing with filters
router.get('/', async (req, res) => {
  try {
    const { category, search, featured, limit=50, page=1 } = req.query;
    const offset = (page-1)*limit;
    let where = ['p.is_active=1'];
    let params = [];

    if (category) { where.push('c.slug=?'); params.push(category); }
    if (featured)  { where.push('p.is_featured=1'); }
    if (search)    { where.push('MATCH(p.name,p.description) AGAINST(? IN BOOLEAN MODE)'); params.push(search+'*'); }

    const sql = `
      SELECT p.*, c.name AS category_name, c.slug AS category_slug,
             ROUND((p.mrp-p.price)/p.mrp*100) AS discount_pct
      FROM   products p
      JOIN   categories c ON p.category_id=c.id
      WHERE  ${where.join(' AND ')}
      ORDER  BY p.is_featured DESC, p.sold_count DESC
      LIMIT  ? OFFSET ?`;

    params.push(parseInt(limit), parseInt(offset));
    const [rows] = await db.query(sql, params);

    const [[{ total }]] = await db.query(
      `SELECT COUNT(*) AS total FROM products p
       JOIN categories c ON p.category_id=c.id
       WHERE ${where.join(' AND ')}`, params.slice(0,-2)
    );

    res.json({ success:true, total, page:parseInt(page), limit:parseInt(limit), products: rows });
  } catch (err) { res.status(500).json({ success:false, message: err.message }); }
});

// GET /api/products/:slug  – single product
router.get('/:slug', async (req, res) => {
  try {
    const [rows] = await db.query(
      `SELECT p.*, c.name AS category_name, c.slug AS category_slug,
              ROUND((p.mrp-p.price)/p.mrp*100) AS discount_pct
       FROM products p JOIN categories c ON p.category_id=c.id
       WHERE p.slug=? AND p.is_active=1`, [req.params.slug]
    );
    if (!rows.length) return res.status(404).json({ success:false, message:'Product not found.' });

    const [reviews] = await db.query(
      `SELECT r.*, u.name AS user_name FROM reviews r
       JOIN users u ON r.user_id=u.id
       WHERE r.product_id=? AND r.is_visible=1 ORDER BY r.created_at DESC LIMIT 20`,
      [rows[0].id]
    );
    res.json({ success:true, product: rows[0], reviews });
  } catch (err) { res.status(500).json({ success:false, message: err.message }); }
});

// POST /api/products  – admin: create product
router.post('/', protect, adminOnly, upload.single('image'), async (req, res) => {
  try {
    const { name, category_id, description, emoji, weight_unit, price, mrp,
            stock, badge, requires_rx, is_featured } = req.body;
    const slug = name.toLowerCase().replace(/[^a-z0-9]+/g,'-').replace(/^-|-$/g,'') + '-' + Date.now();
    const image_url = req.file ? `/uploads/${req.file.filename}` : null;

    const [result] = await db.query(
      `INSERT INTO products (name,slug,category_id,description,emoji,image_url,weight_unit,
        price,mrp,stock,badge,requires_rx,is_featured)
       VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)`,
      [name, slug, category_id, description||'', emoji||'📦', image_url,
       weight_unit||'', parseFloat(price), parseFloat(mrp), parseInt(stock)||0,
       badge||'', requires_rx?1:0, is_featured?1:0]
    );
    res.status(201).json({ success:true, message:'Product created!', id: result.insertId });
  } catch (err) { res.status(500).json({ success:false, message: err.message }); }
});

// PUT /api/products/:id  – admin: update product
router.put('/:id', protect, adminOnly, upload.single('image'), async (req, res) => {
  try {
    const { name, category_id, description, emoji, weight_unit,
            price, mrp, stock, badge, requires_rx, is_featured, is_active } = req.body;
    const updates = [];
    const vals    = [];

    const set = (col, val) => { if (val !== undefined) { updates.push(`${col}=?`); vals.push(val); } };
    set('name', name); set('category_id', category_id); set('description', description);
    set('emoji', emoji); set('weight_unit', weight_unit);
    set('price', price ? parseFloat(price) : undefined);
    set('mrp',   mrp   ? parseFloat(mrp)   : undefined);
    set('stock', stock !== undefined ? parseInt(stock) : undefined);
    set('badge', badge); set('is_active', is_active !== undefined ? (is_active?1:0) : undefined);
    set('requires_rx', requires_rx !== undefined ? (requires_rx?1:0) : undefined);
    set('is_featured', is_featured !== undefined ? (is_featured?1:0) : undefined);
    if (req.file) { updates.push('image_url=?'); vals.push(`/uploads/${req.file.filename}`); }

    if (!updates.length) return res.status(400).json({ success:false, message:'Nothing to update.' });
    vals.push(req.params.id);
    await db.query(`UPDATE products SET ${updates.join(',')} WHERE id=?`, vals);
    res.json({ success:true, message:'Product updated.' });
  } catch (err) { res.status(500).json({ success:false, message: err.message }); }
});

// DELETE /api/products/:id  – admin: soft delete
router.delete('/:id', protect, adminOnly, async (req, res) => {
  try {
    await db.query('UPDATE products SET is_active=0 WHERE id=?', [req.params.id]);
    res.json({ success:true, message:'Product removed from store.' });
  } catch (err) { res.status(500).json({ success:false, message: err.message }); }
});

module.exports = router;
