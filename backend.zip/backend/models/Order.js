const mongoose = require('mongoose');

const orderItemSchema = new mongoose.Schema({
  product:  { type: mongoose.Schema.Types.ObjectId, ref: 'Product' },
  name:     String,
  emoji:    String,
  price:    Number,
  quantity: Number,
  weight:   String
});

const orderSchema = new mongoose.Schema({
  orderId:   { type: String, unique: true },
  user:      { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
  guestInfo: { name: String, phone: String, email: String },
  items:     [orderItemSchema],
  address: {
    name:    String,
    phone:   String,
    line1:   String,
    city:    String,
    state:   String,
    pincode: String
  },
  pricing: {
    subtotal:    Number,
    deliveryFee: { type: Number, default: 40 },
    discount:    { type: Number, default: 0 },
    couponCode:  String,
    total:       Number
  },
  payment: {
    method:            { type: String, enum: ['cod', 'razorpay', 'upi'], default: 'cod' },
    status:            { type: String, enum: ['pending', 'paid', 'failed', 'refunded'], default: 'pending' },
    razorpayOrderId:   String,
    razorpayPaymentId: String
  },
  status: {
    type: String,
    enum: ['pending','confirmed','processing','packed','dispatched','delivered','cancelled'],
    default: 'pending'
  },
  statusHistory: [{
    status: String,
    time:   { type: Date, default: Date.now },
    note:   String
  }],
  deliverySlot:      String,
  estimatedDelivery: Date,
  notes:             String,
  prescription:      String
}, { timestamps: true });

orderSchema.pre('save', function (next) {
  if (!this.orderId) {
    const d = new Date();
    this.orderId = 'ORD-' + d.getFullYear() +
      String(d.getMonth() + 1).padStart(2, '0') +
      String(d.getDate()).padStart(2, '0') + '-' +
      Math.floor(1000 + Math.random() * 9000);
  }
  next();
});

module.exports = mongoose.model('Order', orderSchema);
