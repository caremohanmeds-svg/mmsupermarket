const mongoose = require('mongoose');

const productSchema = new mongoose.Schema({
  name:        { type: String, required: true, trim: true },
  slug:        { type: String, unique: true },
  description: String,
  category: {
    type: String, required: true,
    enum: ['fruits','dairy','staples','snacks','bakery','personal','household','medicine']
  },
  subcategory: String,
  emoji:       { type: String, default: '📦' },
  images:      [String],
  price:       { type: Number, required: true, min: 0 },
  mrp:         { type: Number, required: true, min: 0 },
  weight:      String,
  unit:        String,
  stock:       { type: Number, default: 0, min: 0 },
  minStock:    { type: Number, default: 10 },
  badge:       { type: String, enum: ['', 'sale', 'new', 'hot', 'rx'], default: '' },
  requiresPrescription: { type: Boolean, default: false },
  isActive:    { type: Boolean, default: true },
  isFeatured:  { type: Boolean, default: false },
  tags:        [String],
  ratings: {
    average: { type: Number, default: 0 },
    count:   { type: Number, default: 0 }
  }
}, { timestamps: true });

productSchema.pre('save', function (next) {
  if (!this.slug) {
    this.slug = this.name.toLowerCase().replace(/[^a-z0-9]+/g, '-') + '-' + Date.now();
  }
  next();
});

productSchema.virtual('discount').get(function () {
  return this.mrp > this.price ? Math.round((this.mrp - this.price) / this.mrp * 100) : 0;
});

productSchema.set('toJSON', { virtuals: true });

module.exports = mongoose.model('Product', productSchema);
