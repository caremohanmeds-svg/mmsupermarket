const mongoose = require('mongoose');
const bcrypt = require('bcryptjs');

const addressSchema = new mongoose.Schema({
  label:     { type: String, default: 'Home' },
  line1:     String,
  city:      { type: String, default: 'Prayagraj' },
  state:     { type: String, default: 'Uttar Pradesh' },
  pincode:   String,
  isDefault: { type: Boolean, default: false }
});

const userSchema = new mongoose.Schema({
  name:      { type: String, required: true, trim: true },
  phone:     { type: String, required: true, unique: true, trim: true },
  email:     { type: String, lowercase: true, trim: true },
  password:  { type: String, minlength: 6 },
  role:      { type: String, enum: ['customer', 'admin'], default: 'customer' },
  addresses: [addressSchema],
  isActive:  { type: Boolean, default: true },
  lastLogin: Date,
  otp:       String,
  otpExpiry: Date
}, { timestamps: true });

userSchema.pre('save', async function (next) {
  if (!this.isModified('password') || !this.password) return next();
  this.password = await bcrypt.hash(this.password, 12);
  next();
});

userSchema.methods.matchPassword = function (pw) {
  return bcrypt.compare(pw, this.password);
};

module.exports = mongoose.model('User', userSchema);
