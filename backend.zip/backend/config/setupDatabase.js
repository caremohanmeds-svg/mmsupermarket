// config/setupDatabase.js
// Run: node config/setupDatabase.js
// Creates all tables for MM Supermarket

require('dotenv').config();
const mysql = require('mysql2/promise');

const SQL = `
-- =============================================
--  MM SUPERMARKET DATABASE SCHEMA
-- =============================================

CREATE DATABASE IF NOT EXISTS mmsupermarket_db 
  CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

USE mmsupermarket_db;

-- USERS TABLE
CREATE TABLE IF NOT EXISTS users (
  id          INT AUTO_INCREMENT PRIMARY KEY,
  name        VARCHAR(100) NOT NULL,
  email       VARCHAR(150) UNIQUE,
  phone       VARCHAR(15) UNIQUE NOT NULL,
  password    VARCHAR(255),
  role        ENUM('customer','admin') DEFAULT 'customer',
  is_active   BOOLEAN DEFAULT TRUE,
  otp         VARCHAR(6),
  otp_expires DATETIME,
  created_at  TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at  TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX idx_phone (phone),
  INDEX idx_email (email)
);

-- ADDRESSES TABLE
CREATE TABLE IF NOT EXISTS addresses (
  id         INT AUTO_INCREMENT PRIMARY KEY,
  user_id    INT NOT NULL,
  label      VARCHAR(50) DEFAULT 'Home',
  name       VARCHAR(100) NOT NULL,
  phone      VARCHAR(15) NOT NULL,
  line1      VARCHAR(200) NOT NULL,
  line2      VARCHAR(200),
  city       VARCHAR(100) DEFAULT 'Prayagraj',
  state      VARCHAR(100) DEFAULT 'Uttar Pradesh',
  pincode    VARCHAR(10) NOT NULL,
  is_default BOOLEAN DEFAULT FALSE,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- CATEGORIES TABLE
CREATE TABLE IF NOT EXISTS categories (
  id          INT AUTO_INCREMENT PRIMARY KEY,
  name        VARCHAR(100) NOT NULL,
  slug        VARCHAR(100) UNIQUE NOT NULL,
  emoji       VARCHAR(10),
  description TEXT,
  image_url   VARCHAR(500),
  is_active   BOOLEAN DEFAULT TRUE,
  sort_order  INT DEFAULT 0,
  created_at  TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- PRODUCTS TABLE
CREATE TABLE IF NOT EXISTS products (
  id            INT AUTO_INCREMENT PRIMARY KEY,
  name          VARCHAR(200) NOT NULL,
  slug          VARCHAR(200) UNIQUE NOT NULL,
  category_id   INT NOT NULL,
  description   TEXT,
  emoji         VARCHAR(10) DEFAULT '📦',
  image_url     VARCHAR(500),
  weight_unit   VARCHAR(50),
  price         DECIMAL(10,2) NOT NULL,
  mrp           DECIMAL(10,2) NOT NULL,
  stock         INT DEFAULT 0,
  min_stock     INT DEFAULT 10,
  badge         VARCHAR(20),
  is_active     BOOLEAN DEFAULT TRUE,
  requires_rx   BOOLEAN DEFAULT FALSE,
  is_featured   BOOLEAN DEFAULT FALSE,
  sold_count    INT DEFAULT 0,
  created_at    TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at    TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (category_id) REFERENCES categories(id),
  INDEX idx_category (category_id),
  INDEX idx_active (is_active),
  FULLTEXT idx_search (name, description)
);

-- ORDERS TABLE
CREATE TABLE IF NOT EXISTS orders (
  id               INT AUTO_INCREMENT PRIMARY KEY,
  order_id         VARCHAR(20) UNIQUE NOT NULL,
  user_id          INT,
  name             VARCHAR(100) NOT NULL,
  phone            VARCHAR(15) NOT NULL,
  email            VARCHAR(150),
  address_line1    VARCHAR(200) NOT NULL,
  address_line2    VARCHAR(200),
  city             VARCHAR(100) DEFAULT 'Prayagraj',
  state            VARCHAR(100) DEFAULT 'Uttar Pradesh',
  pincode          VARCHAR(10) NOT NULL,
  subtotal         DECIMAL(10,2) NOT NULL,
  delivery_fee     DECIMAL(10,2) DEFAULT 40.00,
  discount         DECIMAL(10,2) DEFAULT 0.00,
  total            DECIMAL(10,2) NOT NULL,
  payment_method   VARCHAR(50) NOT NULL,
  payment_status   ENUM('pending','paid','failed','refunded') DEFAULT 'pending',
  razorpay_order_id   VARCHAR(100),
  razorpay_payment_id VARCHAR(100),
  status           ENUM('pending','confirmed','processing','packed','out_for_delivery','delivered','cancelled','returned') DEFAULT 'pending',
  notes            TEXT,
  promo_code       VARCHAR(20),
  created_at       TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at       TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL,
  INDEX idx_user (user_id),
  INDEX idx_status (status),
  INDEX idx_order_id (order_id)
);

-- ORDER ITEMS TABLE
CREATE TABLE IF NOT EXISTS order_items (
  id          INT AUTO_INCREMENT PRIMARY KEY,
  order_id    INT NOT NULL,
  product_id  INT NOT NULL,
  name        VARCHAR(200) NOT NULL,
  emoji       VARCHAR(10),
  weight_unit VARCHAR(50),
  price       DECIMAL(10,2) NOT NULL,
  quantity    INT NOT NULL,
  total       DECIMAL(10,2) NOT NULL,
  FOREIGN KEY (order_id) REFERENCES orders(id) ON DELETE CASCADE,
  FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE RESTRICT
);

-- REVIEWS TABLE
CREATE TABLE IF NOT EXISTS reviews (
  id         INT AUTO_INCREMENT PRIMARY KEY,
  product_id INT NOT NULL,
  user_id    INT NOT NULL,
  rating     TINYINT NOT NULL CHECK (rating BETWEEN 1 AND 5),
  comment    TEXT,
  is_visible BOOLEAN DEFAULT TRUE,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE CASCADE,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
  UNIQUE KEY unique_review (product_id, user_id)
);

-- PROMO CODES TABLE
CREATE TABLE IF NOT EXISTS promo_codes (
  id           INT AUTO_INCREMENT PRIMARY KEY,
  code         VARCHAR(20) UNIQUE NOT NULL,
  type         ENUM('percent','fixed') DEFAULT 'percent',
  value        DECIMAL(10,2) NOT NULL,
  min_order    DECIMAL(10,2) DEFAULT 0,
  max_uses     INT DEFAULT 1000,
  used_count   INT DEFAULT 0,
  valid_from   DATETIME,
  valid_until  DATETIME,
  is_active    BOOLEAN DEFAULT TRUE,
  created_at   TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- WISHLISTS TABLE
CREATE TABLE IF NOT EXISTS wishlists (
  id         INT AUTO_INCREMENT PRIMARY KEY,
  user_id    INT NOT NULL,
  product_id INT NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
  FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE CASCADE,
  UNIQUE KEY unique_wishlist (user_id, product_id)
);

-- PRESCRIPTION UPLOADS TABLE (for medicines)
CREATE TABLE IF NOT EXISTS prescriptions (
  id         INT AUTO_INCREMENT PRIMARY KEY,
  user_id    INT NOT NULL,
  order_id   INT,
  file_url   VARCHAR(500) NOT NULL,
  status     ENUM('pending','approved','rejected') DEFAULT 'pending',
  notes      TEXT,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- =============================================
--  SEED: CATEGORIES
-- =============================================
INSERT IGNORE INTO categories (name, slug, emoji, sort_order) VALUES
('Fruits & Vegetables', 'fruits', '🍎', 1),
('Dairy & Eggs',        'dairy',  '🥛', 2),
('Staples & Grains',    'staples','🌾', 3),
('Snacks & Beverages',  'snacks', '🍪', 4),
('Bakery',              'bakery', '🍞', 5),
('Personal Care',       'personal','🧴',6),
('Household',           'household','🧹',7),
('Medicines',           'medicine','💊',8);

-- =============================================
--  SEED: ADMIN USER
-- =============================================
INSERT IGNORE INTO users (name, email, phone, password, role) VALUES
('MM Admin', 'admin@mmsupermarket.in', '9999999999',
 '$2a$10$N9qo8uLOickgx2ZMRZoMyeIjZAgcfl7p92ldGxad68LJZdL17lhy', -- bcrypt of 'Admin@2025'
 'admin');

-- =============================================
--  SEED: PROMO CODE
-- =============================================
INSERT IGNORE INTO promo_codes (code, type, value, min_order, valid_until) VALUES
('MMFRESH10', 'percent', 10, 199, '2025-12-31 23:59:59'),
('WELCOME50', 'fixed',   50, 299, '2025-12-31 23:59:59');
`;

async function setup() {
  const conn = await mysql.createConnection({
    host: process.env.DB_HOST || 'localhost',
    port: process.env.DB_PORT || 3306,
    user: process.env.DB_USER || 'root',
    password: process.env.DB_PASSWORD || '',
    multipleStatements: true
  });
  try {
    console.log('🚀 Setting up MM Supermarket database...');
    await conn.query(SQL);
    console.log('✅ Database and tables created successfully!');
    console.log('✅ Categories seeded.');
    console.log('✅ Admin user created (admin@mmsupermarket.in / Admin@2025)');
    console.log('✅ Promo codes added: MMFRESH10, WELCOME50');
    console.log('\n🎉 Database setup complete! Run: npm start');
  } catch (err) {
    console.error('❌ Error:', err.message);
  } finally {
    await conn.end();
  }
}

setup();
