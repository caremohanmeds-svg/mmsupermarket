# 🚀 MM SUPERMARKET — COMPLETE DEPLOYMENT GUIDE
## Go Live on www.mmsupermarket.in

---

## 📋 WHAT YOU'LL NEED (one-time setup)

| Item | Cost | Where to Get |
|------|------|-------------|
| VPS Server (Hostinger VPS / DigitalOcean) | ₹500–800/month | hostinger.in or digitalocean.com |
| Domain (already have it) | ✅ Done | — |
| Razorpay Account (for UPI payments) | Free | razorpay.com |
| SSL Certificate | FREE | Auto via Let's Encrypt |

---

## STEP 1 — GET A SERVER (VPS)

### Recommended: Hostinger VPS KVM 2 (₹699/month)
1. Go to **hostinger.in → VPS Hosting**
2. Choose **KVM 2** plan (2 vCPU, 8GB RAM, 100GB SSD)
3. Select **Ubuntu 22.04** as the OS
4. After purchase, note your **Server IP Address** (e.g. `123.45.67.89`)

---

## STEP 2 — POINT YOUR DOMAIN TO THE SERVER

1. Log in to your domain registrar (where you bought mmsupermarket.in)
2. Go to **DNS Management**
3. Add/update these DNS records:

```
Type   Name    Value               TTL
A      @       123.45.67.89       300
A      www     123.45.67.89       300
```

4. Wait 15–30 minutes for DNS to propagate

---

## STEP 3 — CONNECT TO YOUR SERVER

Open Terminal (Mac/Linux) or use PuTTY (Windows):

```bash
ssh root@123.45.67.89
# Enter your server password when prompted
```

---

## STEP 4 — INSTALL REQUIRED SOFTWARE

Run these commands on your server one by one:

```bash
# Update system
apt update && apt upgrade -y

# Install Node.js 20
curl -fsSL https://deb.nodesource.com/setup_20.x | bash -
apt install -y nodejs

# Install MySQL
apt install -y mysql-server
mysql_secure_installation
# Follow prompts: set root password, remove anonymous users = Y, 
# disallow remote root = Y, remove test DB = Y, reload = Y

# Install Nginx (web server)
apt install -y nginx

# Install PM2 (keeps Node.js running forever)
npm install -g pm2

# Install Certbot (free SSL)
apt install -y certbot python3-certbot-nginx

# Verify installations
node --version    # should show v20.x
mysql --version
nginx -v
pm2 --version
```

---

## STEP 5 — SET UP THE DATABASE

```bash
# Login to MySQL
mysql -u root -p
# Enter your MySQL root password

# Run these SQL commands:
CREATE DATABASE mmsupermarket_db CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
CREATE USER 'mm_user'@'localhost' IDENTIFIED BY 'StrongPassword@2025';
GRANT ALL PRIVILEGES ON mmsupermarket_db.* TO 'mm_user'@'localhost';
FLUSH PRIVILEGES;
EXIT;
```

---

## STEP 6 — UPLOAD YOUR WEBSITE FILES

### Option A: Using Git (recommended)
```bash
# On your server
cd /var/www
git clone https://github.com/YOUR_USERNAME/mmsupermarket.git
cd mmsupermarket
```

### Option B: Upload via FTP/SFTP (FileZilla)
1. Open FileZilla
2. Host: `123.45.67.89`, Username: `root`, Password: your server password, Port: `22`
3. Upload the entire `mmsupermarket` folder to `/var/www/mmsupermarket`

---

## STEP 7 — CONFIGURE ENVIRONMENT

```bash
cd /var/www/mmsupermarket/backend

# Create your .env file from the template
cp .env.example .env
nano .env
```

Edit `.env` with your real values:

```env
PORT=5000
NODE_ENV=production
FRONTEND_URL=https://www.mmsupermarket.in

# Database
DB_HOST=localhost
DB_NAME=mmsupermarket_db
DB_USER=mm_user
DB_PASSWORD=StrongPassword@2025

# JWT (generate a random 64-char string)
JWT_SECRET=paste_a_long_random_string_here_64_chars_minimum

# Razorpay (from dashboard.razorpay.com > Settings > API Keys)
RAZORPAY_KEY_ID=rzp_live_XXXXXXXXXX
RAZORPAY_KEY_SECRET=XXXXXXXXXXXXXXXXXX
RAZORPAY_WEBHOOK_SECRET=your_webhook_secret

# Email (Gmail App Password)
EMAIL_HOST=smtp.gmail.com
EMAIL_PORT=587
EMAIL_USER=hello@mmsupermarket.in
EMAIL_PASS=your_gmail_app_password
EMAIL_FROM=MM Supermarket <hello@mmsupermarket.in>
```

Save and exit: `Ctrl+X → Y → Enter`

---

## STEP 8 — INSTALL DEPENDENCIES & SET UP DATABASE

```bash
cd /var/www/mmsupermarket/backend

# Install Node.js packages
npm install

# Create uploads folder
mkdir -p uploads
chmod 755 uploads

# Run database setup (creates all tables + seeds data)
node config/setupDatabase.js
```

Expected output:
```
✅ MySQL connected
✅ Database and tables created successfully!
✅ Categories seeded.
✅ Admin user created (admin@mmsupermarket.in / Admin@2025)
✅ Promo codes added: MMFRESH10, WELCOME50
🎉 Database setup complete!
```

---

## STEP 9 — SET UP NGINX (Web Server)

```bash
nano /etc/nginx/sites-available/mmsupermarket
```

Paste this configuration:

```nginx
server {
    listen 80;
    server_name mmsupermarket.in www.mmsupermarket.in;

    # Redirect to HTTPS
    return 301 https://www.$host$request_uri;
}

server {
    listen 443 ssl;
    server_name www.mmsupermarket.in;

    # SSL (filled by Certbot automatically)
    ssl_certificate     /etc/letsencrypt/live/www.mmsupermarket.in/fullchain.pem;
    ssl_certificate_key /etc/letsencrypt/live/www.mmsupermarket.in/privkey.pem;
    ssl_protocols       TLSv1.2 TLSv1.3;
    ssl_ciphers         HIGH:!aNULL:!MD5;

    # File upload size
    client_max_body_size 10M;

    # Serve uploaded images
    location /uploads/ {
        alias /var/www/mmsupermarket/backend/uploads/;
        expires 30d;
        add_header Cache-Control "public, immutable";
    }

    # Proxy API requests to Node.js
    location /api/ {
        proxy_pass         http://localhost:5000;
        proxy_http_version 1.1;
        proxy_set_header   Upgrade $http_upgrade;
        proxy_set_header   Connection 'upgrade';
        proxy_set_header   Host $host;
        proxy_set_header   X-Real-IP $remote_addr;
        proxy_set_header   X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_cache_bypass $http_upgrade;
    }

    # Serve frontend HTML
    location / {
        root  /var/www/mmsupermarket/frontend;
        index index.html;
        try_files $uri $uri/ /index.html;
    }
}
```

Save (`Ctrl+X → Y → Enter`), then:

```bash
# Enable the site
ln -s /etc/nginx/sites-available/mmsupermarket /etc/nginx/sites-enabled/
rm /etc/nginx/sites-enabled/default

# Test Nginx config
nginx -t
# Should say: syntax is ok / test is successful

# Reload Nginx
systemctl reload nginx
```

---

## STEP 10 — GET FREE SSL CERTIFICATE (HTTPS)

```bash
certbot --nginx -d mmsupermarket.in -d www.mmsupermarket.in
# Enter your email, agree to terms
# Choose: Redirect HTTP to HTTPS (option 2)
```

Auto-renewal is configured automatically. ✅

---

## STEP 11 — START THE BACKEND WITH PM2

```bash
cd /var/www/mmsupermarket/backend

# Start the server
pm2 start server.js --name "mmsupermarket-api"

# Save PM2 config (auto-restart on reboot)
pm2 save
pm2 startup
# Copy & run the command it gives you

# Check it's running
pm2 status
pm2 logs mmsupermarket-api
```

---

## STEP 12 — COPY FRONTEND TO WEB DIRECTORY

```bash
# Make the frontend directory
mkdir -p /var/www/mmsupermarket/frontend

# Copy your HTML file
cp /var/www/mmsupermarket/mmsupermarket.html /var/www/mmsupermarket/frontend/index.html
```

Now open the `index.html` and update the API base URL at the top of the `<script>` section:

```javascript
// Add this at the top of your <script> tag in index.html:
const API = 'https://www.mmsupermarket.in/api';

// Then update all fetch calls like:
// OLD: products = [...hardcoded...]
// NEW: fetch(`${API}/products`).then(r => r.json()).then(d => renderProducts(d.data))
```

---

## STEP 13 — SET UP RAZORPAY UPI PAYMENTS

1. Go to **dashboard.razorpay.com**
2. Sign up with your business details (GST/PAN required for live mode)
3. Go to **Settings → API Keys → Generate Live Key**
4. Copy `Key ID` and `Key Secret` into your `.env` file
5. Go to **Settings → Webhooks → Add New Webhook**
   - URL: `https://www.mmsupermarket.in/api/orders/webhook`
   - Secret: make up a secret and add to `.env` as `RAZORPAY_WEBHOOK_SECRET`
   - Events: check `payment.captured`

### Add Razorpay checkout to frontend (index.html):

```html
<!-- Add in <head> -->
<script src="https://checkout.razorpay.com/v1/checkout.js"></script>
```

```javascript
// Replace placeOrder() function in your HTML with:
async function placeOrder() {
  const name  = document.getElementById('co-name').value.trim();
  const phone = document.getElementById('co-phone').value.trim();
  const addr  = document.getElementById('co-addr').value.trim();
  const pin   = document.getElementById('co-pin').value.trim();
  if (!name || !phone || !addr || !pin) { toast('⚠️ Fill all fields'); return; }

  const subtotal = getCartSubtotal();
  const total    = getFinalTotal();

  // Step 1: Create Razorpay order
  const rpRes = await fetch(`${API}/orders/create-razorpay-order`, {
    method:'POST', headers:{'Content-Type':'application/json'},
    body: JSON.stringify({ amount: total })
  }).then(r => r.json());

  // Step 2: Open Razorpay checkout
  const options = {
    key:        rpRes.key_id,
    amount:     rpRes.amount,
    currency:   'INR',
    name:       'MM Supermarket',
    description:'Order Payment',
    order_id:   rpRes.razorpay_order_id,
    prefill:    { name, contact: phone },
    theme:      { color: '#1a56db' },
    handler: async (response) => {
      // Step 3: Confirm order with payment details
      const orderRes = await fetch(`${API}/orders`, {
        method:'POST', headers:{'Content-Type':'application/json'},
        body: JSON.stringify({
          name, phone, address_line1: addr, pincode: pin,
          items: getCartItems(), subtotal, delivery_fee: getDeliveryFee(),
          discount: getDiscount(), total, payment_method: 'UPI',
          razorpay_order_id:   rpRes.razorpay_order_id,
          razorpay_payment_id: response.razorpay_payment_id,
          razorpay_signature:  response.razorpay_signature
        })
      }).then(r => r.json());
      if (orderRes.success) {
        closeModal('checkoutModal');
        cart = {}; updateCartCount(); renderProducts(products);
        toast(`🎉 Order ${orderRes.order_id} placed! Delivery in ~2 hours`);
      }
    }
  };
  new Razorpay(options).open();
}
```

---

## STEP 14 — VERIFY EVERYTHING WORKS ✅

Open your browser and test:

| URL | Expected |
|-----|----------|
| `https://www.mmsupermarket.in` | Your store loads |
| `https://www.mmsupermarket.in/api/health` | `{"status":"ok"}` |
| `https://www.mmsupermarket.in/api/products` | JSON list of products |

---

## DAILY MANAGEMENT COMMANDS

```bash
# View live server logs
pm2 logs mmsupermarket-api

# Restart server (after code changes)
pm2 restart mmsupermarket-api

# View server status
pm2 status

# MySQL: connect to database
mysql -u mm_user -p mmsupermarket_db

# View today's orders
SELECT order_id, name, total, status FROM orders WHERE DATE(created_at) = CURDATE();

# Update order status
UPDATE orders SET status='delivered' WHERE order_id='ORD-20250001';
```

---

## 🔐 SECURITY CHECKLIST

- [ ] Changed default admin password (Admin@2025 → your own)
- [ ] Set a strong JWT_SECRET (64+ random chars)
- [ ] Set a strong DB password
- [ ] Firewall: allow only ports 22, 80, 443
  ```bash
  ufw allow OpenSSH
  ufw allow 'Nginx Full'
  ufw enable
  ```
- [ ] Regular database backups:
  ```bash
  # Add to cron (daily backup at 2 AM)
  crontab -e
  # Add: 0 2 * * * mysqldump -u mm_user -pYOURPASS mmsupermarket_db > /root/backups/mm_$(date +\%Y\%m\%d).sql
  ```

---

## 📞 NEED HELP?

If you get stuck at any step, contact your hosting provider's support or share the error message and I'll help debug it.

**Admin Panel Login:**
- URL: `https://www.mmsupermarket.in` → click Admin button
- Email: `admin@mmsupermarket.in`
- Password: `Admin@2025` ← **Change this immediately after first login!**

---

*Generated for MM Supermarket — www.mmsupermarket.in*
