# 🛒 MM Supermarket — mmsupermarket.in

Full-stack e-commerce website for MM Supermarket, Prayagraj.

## Project Structure
```
mmsupermarket/
├── frontend/
│   └── index.html          ← Your complete website
├── backend/
│   ├── server.js            ← Main Node.js server
│   ├── package.json
│   ├── .env.example         ← Copy to .env and fill values
│   ├── config/
│   │   ├── db.js            ← MySQL connection
│   │   └── setupDatabase.js ← Run once to create tables
│   ├── middleware/
│   │   └── auth.js          ← JWT authentication
│   └── routes/
│       ├── auth.js          ← Register, Login, OTP
│       ├── products.js      ← Product CRUD
│       ├── orders.js        ← Orders + Razorpay UPI
│       └── admin.js         ← Admin dashboard API
└── docs/
    └── DEPLOYMENT_GUIDE.md  ← Step-by-step go-live instructions
```

## Quick Start (Local)
```bash
cd backend
cp .env.example .env       # fill in your values
npm install
node config/setupDatabase.js
npm start
```

## Go Live
See `docs/DEPLOYMENT_GUIDE.md` for complete step-by-step instructions.
